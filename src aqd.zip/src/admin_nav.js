import {Link} from 'react-router-dom'
const Admin_Nav = () => {
    return (
      <div style={{
        width: "250px", 
        height: "100vh", 
        display: "flex", 
        flexDirection: "column", 
        borderRight: "2px solid #ddd", 
        backgroundImage:"url(back.png)",
 
        color: "#fff", 
        padding: "20px 0"
      }}>
        <div style={{
          display: "flex", 
          alignItems: "center", 
          padding: "20px", 
          borderBottom: "1px solid #ddd", 
          marginBottom: "20px"
        }}>
          <img src="logo1.png" alt="logo" style={{ width: "30px", marginRight: "10px" }} />
          <h2 style={{ margin: "auto", fontSize: "20px", fontWeight: "bold" }}>AQUA DROP</h2>
        </div>
        
        <div style={{ display: "flex", flexDirection: "column", marginTop: "20px",gap:"50px" }}>
          {/* Link to Dashboard */}
          <Link to="/admin" style={{
            color: "#ecf0f1", 
            textDecoration: "none", 
            padding: "10px 20px", 
            fontSize: "16px", 
            fontWeight: "500", 
            borderBottom: "1px solid #34495e", 
            transition: "all 0.3s ease", 
            textAlign: "center"
          }} 
          onMouseOver={(e) => e.target.style.backgroundColor = "#34495e"}
          onMouseOut={(e) => e.target.style.backgroundColor = "transparent"}>
            Dashboard
          </Link>
          
          {/* Link to Charts */}
          <Link to="/charts" style={{
            color: "#ecf0f1", 
            textDecoration: "none", 
            padding: "10px 20px", 
            fontSize: "16px", 
            fontWeight: "500", 
            borderBottom: "1px solid #34495e", 
            transition: "all 0.3s ease", 
            textAlign: "center"
          }} 
          onMouseOver={(e) => e.target.style.backgroundColor = "#34495e"}
          onMouseOut={(e) => e.target.style.backgroundColor = "transparent"}>
            Charts
          </Link>
          
          {/* Link to Employees */}
          <Link to="/employees" style={{
            color: "#ecf0f1", 
            textDecoration: "none", 
            padding: "10px 20px", 
            fontSize: "16px", 
            fontWeight: "500", 
            borderBottom: "1px solid #34495e", 
            transition: "all 0.3s ease", 
            textAlign: "center"
          }} 
          onMouseOver={(e) => e.target.style.backgroundColor = "#34495e"}
          onMouseOut={(e) => e.target.style.backgroundColor = "transparent"}>
            Employees
          </Link>
          
          
        </div>
      </div>
    );
  };
  
  export default Admin_Nav;
  