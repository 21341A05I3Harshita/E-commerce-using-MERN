import { Button, Typography, Card, CardContent, Grid } from "@mui/material";
import Admin_Nav from "./admin_nav";
import { useState,useEffect } from "react";
import axios from "axios";
const Total_Order = ()=>{
    const user = JSON.parse(atob(localStorage.getItem("admin")));
    const [od,setOd]=useState([]);

    useEffect(()=>{
        axios.get("http://localhost:8081/get_total_order_details")
        .then((response)=>{
            if(response.status===200){
                setOd(response.data);
            }
        })
        .catch((error)=>{
            console.log(error);
        });
    },[]);
    return (
        <div style={{
          display: "flex", 
          flexDirection: "row", 
          height: "100vh", 
        }}>
          <Admin_Nav />
          <div style={{
            display: "flex", 
            flexDirection: "column", 
            flex: 1, 
            padding: "20px", 
            borderTop: "2px solid black"
          }}>
            <div style={{
              display: "flex", 
              justifyContent: "space-between", 
              alignItems: "center", 
              padding: "10px", 
              borderBottom: "2px solid black",
              gap: "20px"
            }}>
              <div style={{ display: "flex", alignItems: "center" }}>
                <Typography variant="h6" style={{ fontWeight: "bold" }}>
                  GOOD MORNING <span style={{ color: "#1976d2" }}>{user.name}</span>
                </Typography>
              </div>
              <div>
                <Button 
                  variant="contained" 
                  color="primary" 
                  onClick={() => { localStorage.removeItem("admin"); }}
                  style={{
                    padding: "10px 20px", 
                    fontSize: "16px", 
                    textTransform: "none", 
                    backgroundColor: "#1976d2",
                    "&:hover": {
                      backgroundColor: "#1259a1"
                    }
                  }}
                >
                  Logout
                </Button>
              </div>
            </div>
    
            {/* Cards Display for Order Details */}
            <Grid container spacing={3}>
              {od.length > 0 ? (
                od.map((item, index) => (
                  <Grid item xs={12} sm={6} md={4} key={index}>
                    <Card style={{ padding: "15px", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}>
                      <CardContent>
                        <Typography variant="h6" style={{ fontWeight: "bold" }}>Order ID: {item.order_id}</Typography>
                        <Typography variant="body2" color="textSecondary">User: {item.user_name}</Typography>
                        <Typography variant="body2" color="textSecondary">Order Placed: {item.date_order_placed}</Typography>
                        <Typography variant="body2" color="textSecondary">Order Received: {item.order_receieved}</Typography>
                        <Typography variant="body2" color="textSecondary">Product: {item.product_name}</Typography>
                        <Typography variant="body2" color="textSecondary">Quantity: {item.product_quantity}</Typography>
                        <Typography variant="body2" color="textSecondary">Cost: ${item.product_cost}</Typography>
                        <Typography variant="body2" color="textSecondary">Zipcode: {item.user_zipcode}</Typography>
                        <Typography variant="body2" color="textSecondary">State: {item.user_state}</Typography>
                        <Typography variant="body2" color="textSecondary">Post: {item.user_post}</Typography>
                        <Typography variant="body2" color="textSecondary">Address: {item.user_address}</Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))
              ) : (
                <Grid item xs={12}>
                  <Typography variant="h6" style={{ textAlign: "center" }}>No pending orders available</Typography>
                </Grid>
              )}
            </Grid>
          </div>
        </div>
    );
};


export default Total_Order;

