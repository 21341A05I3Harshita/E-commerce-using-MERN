import React, { useState } from 'react';
import { TextField, Button, Box, Alert,Typography} from '@mui/material';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
  const [loginInput, setLoginInput] = useState('');
  const [loginPassword, setPasswordInput] = useState('');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const Navigate = useNavigate();

  const ADMIN_PHONE = process.env.REACT_APP_LOGIN_INPUT;
  const ADMIN_PASSWORD = process.env.REACT_APP_LOGIN_PASSWORD;
  const ID = process.env.REACT_APP_ADMIN_ID;
  const NAME = process.env.REACT_APP_ADMIN_NAME;
  
  const validateInputs = () => {
    const phoneRegex = /^[0-9]{10}$/; // 10-digit phone validation
    if (!phoneRegex.test(loginInput)) {
      setError('Invalid phone number. Please enter a valid 10-digit number.');
      return false;
    }
    if (loginPassword.length === 0) {
      setError('Password cannot be empty.');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    setError(null);
    setSuccess(null);

    if (!validateInputs()) return;
    
    if (loginInput === ADMIN_PHONE && loginPassword === ADMIN_PASSWORD) {
      if (localStorage.getItem('user')) {
        localStorage.removeItem('user');
      }
      
      if (localStorage.getItem('admin')) {
        const admin1 = JSON.parse(atob(localStorage.getItem('admin'))); 
        if(admin1.id===ID && admin1.name === NAME){
          Navigate("/admin");
        }
      } else {
        const admin = {
          id: ID,
          name: NAME
        };
        const encryptedAdmin = btoa(JSON.stringify(admin)); // Base64 encoding for demonstration purposes
        localStorage.setItem('admin', encryptedAdmin);
        Navigate("/admin");
      }
    }
    else{
    

    const requestBody = {
      del_phone: loginInput,
      del_password: loginPassword,
    };

    try {
      const response = await axios.post('http://localhost:8081/del_login', requestBody);
      if (response.status === 200) {
        setSuccess('Login successful!');
        // Store user data in localStorage
        if(localStorage.getItem('admin') ){
          localStorage.removeItem('admin');
        }
        localStorage.setItem('user', JSON.stringify(response.data.user));
        Navigate('/app');
        window.location.reload()
      }
      
    } catch (error) {
      setError(error.response?.data?.error || 'Login failed. Please try again.');
    }
  };
}

  return (
    <div
    style={{
      height: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundImage:"url(back3.png)"
    }}
  >
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        width: "100%",
        maxWidth: 400,
        display: "flex",
        flexDirection: "column",
        gap: 2,
        margin: "0 auto",
        padding: 4,
        backgroundColor: "white",
        borderRadius: "10px", // Rounded corners for modern look
        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)", // Softer shadow
      }}
    >
      <div style={{display:"flex",justifyContent:"space-between"}}>
        <img src="logo1.png" style={{width:"100px"}}/>
      <h1 style={{ textAlign: "center", color: "#333", fontWeight: "bold" }}>
        Login
      </h1>
      </div>
      {error && <Alert severity="error">{error}</Alert>}
      {success && <Alert severity="success">{success}</Alert>}
      <TextField
        label="Phone"
        variant="outlined"
        value={loginInput}
        onChange={(e) => setLoginInput(e.target.value)}
        required
      />
      <TextField
        label="Password"
        type="password"
        variant="outlined"
        value={loginPassword}
        onChange={(e) => setPasswordInput(e.target.value)}
        required
      />
      <Button
        variant="contained"
        color="primary"
        type="submit"
        sx={{
          padding: "10px",
          fontSize: "16px",
          textTransform: "none",
          backgroundColor: "#1976d2",
          "&:hover": {
            backgroundColor: "#1259a1", // Darker hover effect
          },
        }}
      >
        Login
      </Button>
      <Link
        to="/register"
        style={{
          textDecoration: "none",
          color: "#1976d2",
          fontSize: "16px",
          textAlign: "center",
          marginTop: "10px",
          transition: "color 0.3s ease",
        }}
        onMouseEnter={(e) => (e.target.style.color = "#1259a1")}
        onMouseLeave={(e) => (e.target.style.color = "#1976d2")}
      >
        Register
      </Link>
      <Link
        to="/Forgot_Psw"
        style={{
          textDecoration: "none",
          color: "#1976d2",
          fontSize: "16px",
          textAlign: "center",
          marginTop: "10px",
          transition: "color 0.3s ease",
        }}
        onMouseEnter={(e) => (e.target.style.color = "#1259a1")}
        onMouseLeave={(e) => (e.target.style.color = "#1976d2")}
      >
        forgot password?
      </Link>
      <Typography variant="body2" sx={{ marginBottom: '8px',margin:"auto" }}>
        &copy; {new Date().getFullYear()} Your Company Name. All rights reserved.
      </Typography>
      <Typography variant="body2" sx={{margin:"auto"}}>
        Follow us on: 
        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" style={{textDecoration:"none",color:"black", marginLeft: '5px' }}>Facebook</a> | 
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" style={{ textDecoration:"none",color:"black", marginLeft: '5px' }}>Twitter</a> | 
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" style={{ textDecoration:"none",color:"black", marginLeft: '5px' }}>Instagram</a>
      </Typography>
    </Box>
  </div>
  
  );
};

export default Login;
