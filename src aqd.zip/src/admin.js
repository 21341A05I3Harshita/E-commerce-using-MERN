import { Button, Typography } from "@mui/material";
import Admin_Nav from "./admin_nav";
import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Admin = () => {
  const user = JSON.parse(atob(localStorage.getItem("admin")));
  
  
  const [pendingOrders, setPendingOrders] = useState(0);
  const [deliveredOrders, setDeliveredOrders] = useState(0);
  
  
  const [totalOrders, setTotalOrders] = useState(0);
  const Navigate = useNavigate();
  useEffect(() => {
    
axios.get("http://localhost:8081/get_pending")
.then((response) => {
  if (response.status === 200) {
    setPendingOrders(response.data.data);  
  }
})
.catch((error) => {
  console.log(error);
});


axios.get("http://localhost:8081/get_delivered")
.then((response) => {
  if (response.status === 200) {
    setDeliveredOrders(response.data.data);  
  }
})
.catch((error) => {
  console.log(error);
});

  }, []); 

  
  useEffect(() => {
    setTotalOrders(pendingOrders + deliveredOrders);
  }, [pendingOrders, deliveredOrders]); 

  return (
    <div style={{
      display: "flex", 
      flexDirection: "row", 
      height: "100vh", 
    }}>
      <Admin_Nav />
      <div style={{
        display: "flex", 
        flexDirection: "column", 
        flex: 1, 
        padding: "20px", 
        borderTop: "2px solid black"
      }}>
        <div style={{
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center", 
          padding: "10px", 
          borderBottom: "2px solid black",
          gap: "20px"
        }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <Typography variant="h6" style={{ fontWeight: "bold" }}>
              GOOD MORNING <span style={{ color: "#1976d2" }}>{user.name}</span>
            </Typography>
          </div>
          <div>
            <Button 
              variant="contained" 
              color="primary" 
              onClick={() => {localStorage.removeItem("admin");}}
              style={{
                padding: "10px 20px", 
                fontSize: "16px", 
                textTransform: "none", 
                backgroundColor: "#1976d2",
                "&:hover": {
                  backgroundColor: "#1259a1"
                }
              }}
            >
              Logout
            </Button>
          </div>
        </div>

        
        <div style={{ height: "40vh", display: "flex", justifyContent: "space-between", gap: "20px" }}>
          <div
            onClick={() => {Navigate('/pending_order_details')}}
            style={{
            width: "45%", 
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", 
            display: "flex", 
            flexDirection: "column", 
            justifyContent: "center", 
            padding: "20px", 
            backgroundColor: "#fff",
            borderRadius: "8px"
          }}>
            <h1 style={{ textAlign: "center" }}>Pending Orders</h1>
            <Typography style={{ fontSize: "48px", fontWeight: "bold", color: "#1976d2", textAlign: "center" }}>
              {pendingOrders}
            </Typography>
          </div>

          <div
            onClick={() => {Navigate('/delivered_order_details')}}
            style={{
            width: "45%", 
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", 
            display: "flex", 
            flexDirection: "column", 
            justifyContent: "center", 
            padding: "20px", 
            backgroundColor: "#fff",
            borderRadius: "8px"
          }}>
            <h1 style={{ textAlign: "center" }}>Delivered Orders</h1>
            <Typography style={{ fontSize: "48px", fontWeight: "bold", color: "#1976d2", textAlign: "center" }}>
              {deliveredOrders}
            </Typography>
          </div>
        </div>

        
        <div style={{
          height: "40vh", 
          display: "flex", 
          justifyContent: "center", 
          padding: "20px"
        }}>
          <div
            onClick={() => {Navigate("/total_order_details")}} 
            style={{
            width: "45%", 
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", 
            display: "flex", 
            flexDirection: "column", 
            justifyContent: "center", 
            padding: "20px", 
            backgroundColor: "#fff",
            borderRadius: "8px"
          }}>
            <h1 style={{ textAlign: "center" }}>Total Number of Orders</h1>
            <Typography style={{ fontSize: "48px", fontWeight: "bold", color: "#1976d2", textAlign: "center" }}>
              {totalOrders}
            </Typography>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;
