import { Button, Typography, Select, MenuItem, FormControl, InputLabel } from "@mui/material";
import Admin_Nav from "./admin_nav";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from "recharts";
import { useEffect, useState } from "react";
import axios from "axios";

const CombinedCharts = () => {
  const user = JSON.parse(atob(localStorage.getItem("admin")));
  const [pieChartData, setPieChartData] = useState([]);
  const [barChartData, setBarChartData] = useState([]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());  // Default to current year
  const [years, setYears] = useState([2020, 2021, 2022, 2023, 2024]); // Example years

  // Define colors for pie chart
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#A28CFE"];

  // Fetch product sales data for Pie chart
  useEffect(() => {
    axios.get("http://localhost:8081/product_analysis")
      .then((response) => {
        if (response.status === 200) {
          setPieChartData(response.data);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  // Fetch monthly sales data for Bar chart based on selected year
  useEffect(() => {
    axios.get(`http://localhost:8081/monthlysales?year=${selectedYear}`)
      .then((response) => {
        if (response.status === 200) {
          const months = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
          ];

          // Format data with month names
          const formattedData = months.map((month, index) => {
            const monthData = response.data.find(item => item.month === index + 1);
            return {
              month,
              total_sold: monthData ? monthData.total_sold : 0
            };
          });

          setBarChartData(formattedData);
        }
      })
      .catch((error) => {
        console.error("Error fetching monthly sales data:", error);
      });
  }, [selectedYear]);

  return (
    <div style={{ display: "flex", flexDirection: "row", height: "100vh" }}>
      <Admin_Nav />
      <div style={{ display: "flex", flexDirection: "column", flex: 1, padding: "20px", borderTop: "2px solid black" }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px", borderBottom: "2px solid black", gap: "20px" }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <Typography variant="h6" style={{ fontWeight: "bold" }}>
              GOOD MORNING <span style={{ color: "#1976d2" }}>{user.name}</span>
            </Typography>
          </div>
          <div>
            <Button 
              variant="contained" 
              color="primary" 
              onClick={() => { localStorage.removeItem("admin"); }}
              style={{ padding: "10px 20px", fontSize: "16px", textTransform: "none", backgroundColor: "#1976d2" }}
            >
              Logout
            </Button>
          </div>
        </div>
        
        

        {/* Pie Chart for Product Sales */}
        <div style={{ flex: 1, height: "400px" }}>
          <Typography variant="h6" style={{ marginBottom: "10px" }}>Product Sales Proportion</Typography>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieChartData}
                dataKey="total_sold"
                nameKey="product_name"
                cx="50%"
                cy="50%"
                outerRadius={150}
                fill="#8884d8"
                label={({ name }) => name}
              >
                {pieChartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

{/* Year Filter for Bar Chart */}
<div style={{ marginBottom: "20px" }}>
          <FormControl variant="outlined">
            <InputLabel>Year</InputLabel>
            <Select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              label="Year"
            >
              {years.map((year) => (
                <MenuItem key={year} value={year}>
                  {year}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>
        {/* Bar Chart for Monthly Sales */}
        <div style={{ flex: 1, height: "300px", marginTop: "20px" }}>
          <Typography variant="h6" style={{ marginBottom: "10px" }}>Monthly Sales for {selectedYear}</Typography>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barChartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="total_sold" fill="#1976d2" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default CombinedCharts;
