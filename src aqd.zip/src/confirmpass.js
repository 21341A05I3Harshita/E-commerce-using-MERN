import axios from "axios";
import { TextField, Button, Box } from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Confirm_Pass = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email format");
            return;
        }

        if (password.length < 6) {
            alert("Password must be at least 6 characters long");
            return;
        }

        const requestBody = {
            del_email: email,
            del_password: password,
        };

        axios.post('http://localhost:8081/confirm_passw', requestBody)
            .then((response) => {
                if (response.status === 201) {
                    navigate('/login');
                }
            })
            .catch((error) => {
                console.error("Error during request:", error);
                alert("An error occurred. Please try again.");
            });
    };

    return (
        <div
            style={{
                height: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                backgroundImage: "url(back3.png)"
            }}
        >
            <Box
                component="form"
                onSubmit={handleSubmit} // Attach handleSubmit to the form
                sx={{
                    display: "flex",
                    flexDirection: "column",
                    padding: 5,
                    backgroundColor: "white",
                    gap: 3
                }}
            >
                <TextField
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    label="Enter your email"
                    required
                    sx={{ width: "450px" }}
                />
                <TextField
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    label="New password"
                    type="password"
                    required
                    sx={{ width: "450px" }}
                />
                <Button
                    type="submit"
                    variant="outlined"
                    sx={{
                        color: "black",
                        border: "1px solid black",
                        "&:hover": {
                            color: "white",
                            backgroundColor: "black",
                            border: "2px solid white"
                        }
                    }}
                >
                    Submit
                </Button>
            </Box>
        </div>
    );
};

export default Confirm_Pass;
 