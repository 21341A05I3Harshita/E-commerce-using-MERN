import { Box } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import {Link} from "react-router-dom";


const App = () => {
  const user = JSON.parse(localStorage.getItem("user")) || {};
  const [orders, setOrders] = useState([]);

  const formatDate = (dateorder) => {
    const date = new Date(dateorder);
    return date.toISOString().split("T")[0];
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.post("http://localhost:8081/get_del_orders", {
          user_district: user.dist, // Matches backend expectation
        });
        if (response.status === 200) {
          setOrders(response.data);
        }
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };
    fetchData();
  }, [user.district]); // Add user.district to dependencies

  return (
    <>
    <div style={{width: "100%",height: "50vh",overflow: "auto",}}>
      
      
      <Box
        sx={{
          padding: "20px",
          backgroundColor: "#fff",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
          borderRadius: "8px",
          marginBottom: "20px",
        }}
      >
        <h2>Orders</h2>
        
        {orders.length > 0 ? (
          orders.map((item, index) => (
            <Link
            to={`/order/${item.order_id}`}
            style={{ textDecoration: "none" }}
            key={index}
            state={{ orderDetails: item }}
          >
        
            <Box
              key={index}
              sx={{
                marginBottom: "20px",
                padding: "15px",
                backgroundColor: "#f9f9f9",
                borderRadius: "8px",
                boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
              }}
            >
              <h1 style={{ fontSize: "18px", fontWeight: "bold", color: "#333", marginBottom: "8px" }}>
                Order ID: {item.order_id}
              </h1>
              <h1 style={{ fontSize: "18px", fontWeight: "bold", color: "#333", marginBottom: "8px" }}>
                Order Placed: {formatDate(item.date_order_placed)}
              </h1>
              <p
                style={{
                  fontSize: "14px",
                  color: item.order_receieved==='not_yet_received' ? "#f44336" : "#4CAF50",
                  fontWeight: "bold",
                  marginBottom: "8px",
                }}
              >
                Status: {item.order_receieved==='not_yet_received' ? "Pending" : "Delivered"}
              </p>
              <h2 style={{ fontSize: "16px", fontWeight: "500", color: "#333", marginBottom: "8px" }}>
                Product: {item.product_name}
              </h2>
              <h3 style={{ fontSize: "14px", color: "#666", marginBottom: "4px" }}>
                Ship to: <span style={{ fontWeight: "normal", color: "#333" }}>{item.user_name}</span>
              </h3>
              <h3 style={{ fontSize: "14px", color: "#666", margin: 0 }}>
                Total: <span style={{ fontWeight: "normal", color: "#333" }}>{item.product_cost.toFixed(2)}/-</span>
              </h3>
            </Box>
            </Link>
            
          ))
        ) : (
          <p style={{ fontSize: "16px", color: "#999" }}>No orders found.</p>
        )}
      </Box>
    </div>
    
    </>
  );
};

export default App;
