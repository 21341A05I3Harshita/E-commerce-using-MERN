import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Register from './register';
import Login from './login';
import reportWebVitals from './reportWebVitals';
import OrderDetails from './orderDetail';
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Del_Navbar from './del_navbar';
import Footer from './footer';
import Forgot_Psw from './forgot_psw';
import Forgot_Psw_Otp from './forgot_psw_otp';
import Confirm_Pass from './confirmpass';
import Admin from './admin';
import Charts from './charts';
import Employees from './employees';
import Pending_Order from './pend_order';
import Delivered_Order from './deli_order';
import Total_Order from './total_order';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
  {localStorage.getItem('user')!==null || undefined ? <Del_Navbar/>  :""}
    <Routes>
      <Route
        path="/"
        element={localStorage.getItem('user') !== null ? <App /> : <Navigate to="/login" />}
      />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/app" element={<App />} />
      <Route path="/order/:orderId" element={<OrderDetails />} />
      <Route path="/Forgot_Psw" element={<Forgot_Psw />} />
      <Route path="/enterotp" element={<Forgot_Psw_Otp />} />
      <Route path="/confirm_password" element={<Confirm_Pass />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/charts" element={<Charts />} />
      <Route path="/employees" element={<Employees />} />
      <Route path="/pending_order_details" element={<Pending_Order />} />
      <Route path='/delivered_order_details' element={<Delivered_Order/>}/>
      <Route path='/total_order_details' element={<Total_Order/>}/>
      
    </Routes>
    {localStorage.getItem('user')!==null || undefined ? <Footer/>  :""}
  </BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
