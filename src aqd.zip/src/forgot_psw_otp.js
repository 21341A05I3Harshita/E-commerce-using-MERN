import { Box, Button, TextField } from "@mui/material";
import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Forgot_Psw_Otp = () => {
    const navigate = useNavigate();
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!otp) {
            setError("Please enter the OTP.");
            return;
        }

        setError(""); // Clear previous error message
        axios.post('http://localhost:8081/confirm_pass', { otp }) // Send OTP as an object
            .then((response) => {
                if (response.status === 200) {
                    navigate("/confirm_password");
                }
            })
            .catch((error) => {
                console.error("Error verifying OTP:", error);
                if (error.response && error.response.data) {
                    setError(error.response.data.message);
                } else {
                    setError("An error occurred. Please try again.");
                }
            });
    };

    return (
        <div
            style={{
                height: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                backgroundImage: "url(back3.png)"
            }}
        >
            <Box
                component="form"
                onSubmit={handleSubmit} // Attach handleSubmit to the form
                sx={{
                    display: "flex",
                    flexDirection: "column",
                    padding: 5,
                    backgroundColor: "white",
                    gap: 3
                }}
            >
                <TextField
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    label="OTP"
                    required
                    sx={{ width: "450px" }}
                    error={!!error}
                    helperText={error}
                />
                <Button
                    type="submit"
                    variant="outlined"
                    sx={{
                        color: "black",
                        border: "1px solid black",
                        "&:hover": {
                            color: "white",
                            backgroundColor: "black",
                            border: "2px solid white"
                        }
                    }}
                >
                    Submit
                </Button>
            </Box>
        </div>
    );
};

export default Forgot_Psw_Otp;
