import React, { useState } from 'react';
import { TextField, Button, Box, Alert,Typography } from '@mui/material';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Register = () => {
  const [formData, setFormData] = useState({
    user_name: '',
    user_state: '',
    user_district: '',
    user_phone: '',
    user_email: '',
    user_password: '',
    user_confirm_password: '',
  });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    const phoneRegex = /^[0-9]{10}$/; // Validate 10-digit phone number
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email format
    if (!phoneRegex.test(formData.user_phone)) {
      setError("Invalid phone number format. Please enter a valid 10-digit number.");
      return false;
    }
    if (!emailRegex.test(formData.user_email)) {
      setError("Invalid email format. Please enter a valid email address.");
      return false;
    }
    if (formData.user_password !== formData.user_confirm_password) {
      setError("Passwords do not match!");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!validateForm()) return;

    const requestBody = {
      del_name: formData.user_name,
      del_state: formData.user_state,
      del_district: formData.user_district,
      del_phone: formData.user_phone,
      del_email: formData.user_email,
      del_password: formData.user_password,
    };

    try {
      const response = await axios.post('http://localhost:8081/del_register', requestBody);
      if (response.status === 201) {
        setSuccess('Registration successful!');
        setFormData({
          user_name: '',
          user_state: '',
          user_district: '',
          user_phone: '',
          user_email: '',
          user_password: '',
          user_confirm_password: '',
        });
      }
    } catch (error) {
      setError(error.response?.data?.error || "Registration failed. Please try again.");
    }
  };

  return (
    <div style={{
      height: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundImage:"url(back3.png)"
    }}>
      
    <Box
    component="form"
    onSubmit={handleSubmit}
    sx={{
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      maxWidth: 600,
      margin: 'auto',
      padding: 4,
      backgroundColor:"white",
      borderRadius: "10px", // Rounded corners for modern look
      boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)", // Softer shadow
    }}
    >
      <div style={{display:"flex",justifyContent:"space-between"}}>
        <img src='logo1.png' style={{width:"100px"}}/>
        <h1>signup</h1>
      </div>
      {error && <Alert severity="error">{error}</Alert>}
      {success && <Alert severity="success">{success}</Alert>}
      <div style={{display:"flex",justifyContent:"space-between",gap:"8px"}}>
      <TextField
        label="Name"
        name="user_name"
        variant="outlined"
        value={formData.user_name}
        sx={{width:"400px"}}
        onChange={handleChange}
        required
      />
      <TextField
        label="State"
        name="user_state"
        variant="outlined"
        value={formData.user_state}
        sx={{width:"400px"}}
        
        onChange={handleChange}
        required
      />
      </div>
      <div style={{display:"flex",justifyContent:"space-between",gap:"8px"}}>
      <TextField
        label="District"
        name="user_district"
        variant="outlined"
        value={formData.user_district}
        sx={{width:"400px"}}
        onChange={handleChange}
        required
      />
      <TextField
        label="Phone"
        name="user_phone"
        variant="outlined"
        value={formData.user_phone}
        sx={{width:"400px"}}
        onChange={handleChange}
        required
      />
      </div>
      <TextField
        label="Email"
        name="user_email"
        type="email"
        variant="outlined"
        value={formData.user_email}
        onChange={handleChange}
        required
      />
      <div style={{display:"flex",justifyContent:"space-between",gap:"8px"}}>
      <TextField
        label="Password"
        name="user_password"
        type="password"
        variant="outlined"
        value={formData.user_password}
        sx={{width:"400px"}}
        onChange={handleChange}
        required
      />
      <TextField
        label="Confirm Password"
        name="user_confirm_password"
        type="password"
        variant="outlined"
        value={formData.user_confirm_password}
        sx={{width:"400px"}}
        onChange={handleChange}
        required
      />
      </div>
      <Button variant="contained" color="primary" type="submit">
        Register
      </Button>
      <Link
        to="/login"
        style={{
          textDecoration: "none",
          color: "#1976d2",
          fontSize: "16px",
          textAlign: "center",
          marginTop: "10px",
          transition: "color 0.3s ease",
        }}
        onMouseEnter={(e) => (e.target.style.color = "#1259a1")}
        onMouseLeave={(e) => (e.target.style.color = "#1976d2")}
      >
        Register
      </Link>
      <Typography variant="body2" sx={{ marginBottom: '8px',margin:"auto" }}>
        &copy; {new Date().getFullYear()} Your Company Name. All rights reserved.
      </Typography>
      <Typography variant="body2" sx={{margin:"auto"}}>
        Follow us on: 
        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" style={{textDecoration:"none",color:"black", marginLeft: '5px' }}>Facebook</a> | 
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" style={{ textDecoration:"none",color:"black", marginLeft: '5px' }}>Twitter</a> | 
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" style={{ textDecoration:"none",color:"black", marginLeft: '5px' }}>Instagram</a>
      </Typography>
    </Box>
    </div>
  );
};

export default Register;
