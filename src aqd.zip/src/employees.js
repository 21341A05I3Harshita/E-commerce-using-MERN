import { Button, Typography, Card, CardContent, CardActions, Grid } from "@mui/material";
import Admin_Nav from "./admin_nav";
import { useEffect, useState } from "react";
import axios from "axios";

const Employees = () => {
  const [employees, setEmployees] = useState([]);  
  const user = JSON.parse(atob(localStorage.getItem("admin")));

  useEffect(() => {
    axios.get("http://localhost:8081/get_employees")
      .then((response) => {
        if (response.status === 200) {
          setEmployees(response.data);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div style={{
      display: "flex", 
      flexDirection: "row", 
      height: "100vh",
    }}>
      <Admin_Nav />
      <div style={{
        display: "flex", 
        flexDirection: "column", 
        flex: 1, 
        padding: "20px", 
        borderTop: "2px solid black"
      }}>
        <div style={{
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center", 
          padding: "10px", 
          borderBottom: "2px solid black",
          gap: "20px"
        }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <Typography variant="h6" style={{ fontWeight: "bold" }}>
              GOOD MORNING <span style={{ color: "#1976d2" }}>{user.name}</span>
            </Typography>
          </div>
          <div>
            <Button 
              variant="contained" 
              color="primary" 
              onClick={() => { localStorage.removeItem("admin"); }}
              style={{
                padding: "10px 20px", 
                fontSize: "16px", 
                textTransform: "none", 
                backgroundColor: "#1976d2",
                "&:hover": {
                  backgroundColor: "#1259a1"
                }
              }}
            >
              Logout
            </Button>
          </div>
        </div>

        {/* Cards Display */}
        <Grid container spacing={3}>
          {employees.length > 0 ? (
            employees.map((item, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card style={{ padding: "10px", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}>
                  <CardContent>
                    <Typography variant="h6" style={{ fontWeight: "bold" }}>{item.del_name}</Typography>
                    <Typography variant="body2" color="textSecondary">{item.del_email}</Typography>
                    <Typography variant="body2" color="textSecondary">{item.del_phone}</Typography>
                    <Typography variant="body2" color="textSecondary">{item.del_state}</Typography>
                    <Typography variant="body2" color="textSecondary">{item.del_district}</Typography>
                  </CardContent>
                  <CardActions>
                    <Button size="small" color="primary" onClick={() => alert(`Contacting ${item.del_name}`)}>
                      Contact
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            ))
          ) : (
            <Grid item xs={12}>
              <Typography variant="h6" style={{ textAlign: "center" }}>No results</Typography>
            </Grid>
          )}
        </Grid>
      </div>
    </div>
  );
};

export default Employees;
