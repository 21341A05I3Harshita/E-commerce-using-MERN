import { Box, Button, TextField } from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Forgot_Psw = () => {
    const generateOTP = () => {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let otp = '';
        for (let i = 0; i < 6; i++) {
            otp += characters[Math.floor(Math.random() * characters.length)];
        }
        return otp;
    };

    const navigate = useNavigate();
    const [e_mail,setE_mail] = useState('');
    const handleSubmit = (e)=>{
        //give me standard email 
        //generate otp of 6 digts consists of both alphabet and numbers
        e.preventDefault();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(e_mail)){
            alert("please enter email in correct email format");
        }
        const s_otp=generateOTP();
        const requestBody={
            del_email:e_mail,
            del_otp:s_otp
        };
        axios.post('http://localhost:8081/send_f_otp',requestBody)
        .then((respose)=>{
            if(respose.status ===200){
                navigate('/enterotp');
            }
        })
        .catch((error)=>{
            console.log(error);
        });
        
    };
    return (
        <div
        style={{
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          backgroundImage:"url(back3.png)"
        }}
      >
        <Box component="form" onSubmit={handleSubmit} sx={{display:"flex",flexDirection:"column",padding:5,backgroundColor:"white",gap:3}}>
            <TextField label="e-mail" onChange={(e)=>{setE_mail(e.target.value)}} required sx={{width:"450px"}}/>
            <Button type="submit" variant="outlined" sx={{color:"black",border:"1px solid black","&:hover":{color:"white",backgroundColor:"black",border:"2px solid white"}}}>submit</Button>
        </Box>

      </div>
    );    
};

export default Forgot_Psw;