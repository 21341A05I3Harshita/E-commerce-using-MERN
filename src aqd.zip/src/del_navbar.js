import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { Button, Menu, MenuItem, Table, TableRow, TableCell } from '@mui/material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Del_Navbar = () => {
  const [anchorEl, setAnchorEl] = useState(null); // Updated state type
  const user = JSON.parse(localStorage.getItem("user")) || {};
  const navigate = useNavigate();

  // Handle menu open/close
  const handleMenuOpen = (event) => setAnchorEl(event.currentTarget);
  const handleMenuClose = () => setAnchorEl(null);

  // Logout function
  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate('/login'); // Redirect to login 
    window.location.reload()
  };

  return (
    <div style={{ display: "flex", justifyContent: "space-between", backgroundColor: "#65A5BA", padding: "10px 20px",backgroundImage:"url(back3.png)" }}>
      {/* Logo and Title */}
      <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
        <img src="logo1.png" alt="logo AD" style={{ width: "80px", height: "auto" }} />
        <h1 style={{ color: "white", margin: 0 }}>AQUA DROP</h1>
      </div>

      {/* Profile and Logout */}
      <div style={{ display: "flex", alignItems: "center", gap: "20px", color: "white" }}>
        <AccountCircleIcon
          sx={{
            transition: "0.3s",
            width: "50px",
            height: "50px",
            cursor: "pointer",
            "&:hover": { color: "black" },
          }}
          onClick={handleMenuOpen} // Open menu on click
        />
        <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
          <MenuItem>
            <Table sx={{ width: "100%", borderCollapse: "collapse" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold" }}>Name:</TableCell>
                <TableCell>{user.name}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold" }}>Phone:</TableCell>
                <TableCell>{user.phone}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold" }}>Email:</TableCell>
                <TableCell>{user.email}</TableCell>
              </TableRow>
            </Table>
          </MenuItem>
        </Menu>

        <Button
          variant="outlined"
          sx={{
            padding: "8px 16px",
            color: "black",
            border: "1px solid white",
            backgroundColor: "white",
            transition: "0.3s",
            "&:hover": { backgroundColor: "black", color: "white", border: "black" },
          }}
          onClick={handleLogout}
        >
          Logout
        </Button>
      </div>
    </div>
  );
};

export default Del_Navbar;
