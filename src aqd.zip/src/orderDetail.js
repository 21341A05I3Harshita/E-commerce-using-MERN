import { Box,Button } from "@mui/material";
import axios from "axios";
import { useParams,useLocation } from "react-router-dom";

const OrderDetails =()=>{
    const generateOTP = () => {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let otp = '';
        for (let i = 0; i < 6; i++) {
          const randomIndex = Math.floor(Math.random() * characters.length);
          otp += characters[randomIndex];
        }
        return otp;
      };
      
    const send_OTP=()=>{
        const otp =generateOTP();
        const requestBody={
            order_id: orderDetails.order_id,
            order_otp:otp,
            user_email: orderDetails.user_email
        };
        axios.post('http://localhost:8081/store_otp',requestBody)
        .then((response)=>{
            if((response.status===200)){
                alert('otp sent ');
            }

        })
        .catch((error)=>{
            console.log(error);
        });
    };

    const { orderId } = useParams();
    const location = useLocation();
    const orderDetails = location.state?.orderDetails;
  
   return(
<Box sx={{ padding: "20px" }}>
      <h1>Order Details</h1>
      {orderDetails ? (
        <Box
          sx={{
            padding: "20px",
            backgroundColor: "#f5f5f5",
            borderRadius: "8px",
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
          }}
        >
          <h2>Order ID: {orderDetails.order_id}</h2>
          <h2>Product: {orderDetails.product_name}</h2>
          <h3>Status: {orderDetails.order_receieved==="not_yet_received"?"pending" :"delivered"}</h3>
          <h3>Placed On: {orderDetails.date_order_placed}</h3>
          <h3>Total: {orderDetails.product_cost}/-</h3>
          {orderDetails.order_receieved==="not_yet_received"?(
          <Button onClick={send_OTP} >send otp</Button>
          ):
          ('')
          };
        </Box>
      ) : (
        <p>Loading order details...</p>
      )}
    </Box>
    );
};

export default OrderDetails;