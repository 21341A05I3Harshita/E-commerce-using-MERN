import React from 'react';
import { BrowserRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';

import Login from './login';
import Signup from './signup';
import Products from './products';
import Navbar from './navbar';
import App from './App';
import ProductBottles from './productbottles';
import ProductPackets from './productpackets';
import Productcan from './productcan';
import  ProductDetails  from "./productdetail";
import Services1 from './servieces1';
import About1 from './about1';
import Contact1 from './contact1';
import PlaceOrder from './placingorder';
import PlaceOrderNavbar from './placeordernavbar';
import Orders from './orders';
import OrderDetails from './orderdetails';
const CustomNavbar = () => {
  const location = useLocation();
  const navigate = useNavigate();

  if(location.pathname === '/placingorder'){
    return <PlaceOrderNavbar/>
  }
  else{
    return localStorage.getItem('user')!==null || undefined ? <Navbar/>  :"";
    
  }
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    {/* Only show the Navbar if a user is logged in */}
    <CustomNavbar/>
    <Routes>
      <Route path='/' element={<Login/>} /> {/* Login as default route */}
      <Route path='/login' element={<Login />} />
      <Route path='/signup' element={<Signup />} />
      <Route path='/products' element={<Products/>}/>
      <Route path='/App' element={<App />}/>
      <Route path='/productbottles' element={<ProductBottles/>}/>
      <Route path='/productpackets' element={<ProductPackets/>}/>
      <Route path='/productcan' element={<Productcan/>}/>
      <Route path="/productpackets/:id" element={<ProductDetails/>} />
      <Route path="/products/:id" element={<ProductDetails/>} />
      <Route path='/servieces1' element={<Services1/>} />
      <Route path='/about1' element={<About1/>} />
      <Route path='/contact1' element={<Contact1/>} />
      <Route path='/placingorder' element={<PlaceOrder/>}/>
      <Route path='/orders' element={<Orders/>}/>
      <Route path="/orders/:orderId" element={<OrderDetails />} />

    </Routes>
  </BrowserRouter>
);

// Measuring performance
reportWebVitals();
