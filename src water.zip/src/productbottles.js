import React from "react";
import { Box, Button } from "@mui/material";
import Footer from "./footer";
import { useNavigate } from "react-router-dom";

const ProductBottles = () => {
    const navigate = useNavigate();

    const handleProductClick=(id)=>{
      navigate(`/products/${id}`);
    }
    return (
        <>
            <div style={{ marginTop: "100px", marginBottom: "20px", width: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: "20px" }}>
                <Box
                    sx={{
                        backgroundImage: "url('/productpage/product_image.png')",
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "100% 100%",
                        width: "100%",
                        height: "50vh",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "white",
                        textAlign: "center",
                    }}
                >
                    <h1 style={{ fontSize: "3rem", fontWeight: "bold", margin: "0",color:"white" }}>Products</h1>
                    <p style={{ fontSize: "1.2rem", marginTop: "10px",color:"white" }}>home / product</p>
                </Box>
                <div style={{ width: "80%", display: "flex", flexDirection: "column", alignItems: "center", gap: "30px" }}>
                    <div style={{ width: "100%", display: "flex", justifyContent: "center", gap: "20px", flexWrap: "wrap" }}>
                    <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img onClick={()=>handleProductClick(4)} src="/products/bottles/250ml.png" alt="250ml bottle" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>5.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>250ml bottle</p>
                        </Box>
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img onClick={()=>handleProductClick(5)} src="/products/bottles/1000ml.png" alt="1L bottle" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>10.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>1L bottle</p>
                            
                            
                        </Box>
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img onClick={()=>handleProductClick(6)} src="/products/bottles/2000ml.png" alt="2L bottle" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>20.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>2L bottle</p>
                            
                            
                        </Box>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
};

export default ProductBottles;
