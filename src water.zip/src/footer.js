// Footer.js
import React from 'react';
import { Box, Typography } from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import CallIcon from '@mui/icons-material/Call';
import EmailIcon from '@mui/icons-material/Email';



const Footer = () => {
  return (
    <Box 
      component="footer" 
      sx={{ 
        backgroundColor: '#65A5BA', 
        color: 'white', 
        padding: '16px 0', 
        textAlign: 'center',
        position: 'relative',
        bottom: 0,
        width: '100%'
      }}>
        <Box
        sx={{display: 'flex',
        justifyContent: 'center',
        gap:'230px'}}>
            <Box
            sx={{display: 'flex',
              flexDirection: 'column',
              alignItems: 'start',
              gap: '5px',
              padding: '20px',}}>
                <Box
                sx={{display: 'flex', // Centers items vertically
                  justifyContent: 'space-between',
                  }}>
                    <img src="logo1.png" alt="footer-logo" style={{  width: '70px', height: 'auto' }} />
                    <h2 style={{ color: "white" }}>AQUA DROP</h2>
                </Box>
              <p style={{ textAlign: 'justify', maxWidth: '300px' }}>There are many variations of passages of<br />
              Lorem Ipsum available, but the majority<br />
              have suffered alteration.
              </p>
              <h3 style={{ textAlign: 'justify' }}>Open Hours:</h3>
              <p style={{ textAlign: 'justify' }}>Mon-Sat: 9AM-6PM.<br/>Sunday: Closed</p>
              </Box>
              <Box
              sx={{padding:"20px",display:"flex",flexDirection:"column",alignItems:"flex-start"}}>
                <h2 style={{color:"white",}}>Address:</h2>
                <div style={{display:"flex"}}><LocationOnIcon/><p style={{paddingLeft:"10px"}}>asgagaga</p></div>
                <div style={{display:"flex"}}><CallIcon/><p style={{paddingLeft:"10px"}}>call us:</p></div>
                <div style={{display:"flex"}}><EmailIcon/><p style={{paddingLeft:"10px"}}>abhiramvadaga@gmail.com</p></div>
              </Box>
              <Box
              sx={{padding: "20px",
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",}}>
                  <h2 style={{ color: "white" }}>Location:</h2>
                  <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3168.953545956644!2d-122.08424968476803!3d37.42199997982515!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808fba7deef5e631%3A0x8c48425e4fdfdc27!2sGoogleplex!5e0!3m2!1sen!2sus!4v1666528714411!5m2!1sen!2sus"
                  width="100%"
                  height="200"
                  style={{ border: "0",borderRadius:"25px", marginTop: "10px" }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade">
                  </iframe>
              </Box>
        </Box>
      <Typography variant="body2" sx={{ marginBottom: '8px' }}>
        &copy; {new Date().getFullYear()} Your Company Name. All rights reserved.
      </Typography>
      <Typography variant="body2">
        Follow us on: 
        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" style={{ color: 'white', marginLeft: '5px' }}>Facebook</a> | 
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" style={{ color: 'white', marginLeft: '5px' }}>Twitter</a> | 
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" style={{ color: 'white', marginLeft: '5px' }}>Instagram</a>
      </Typography>
    </Box>
  );
};

export default Footer;
