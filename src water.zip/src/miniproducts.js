import React from "react";
import './miniproducts.css'

const Miniproduct = ()=>{
    return(
    <div className="maindiv">
  <div className="item">
    <img src="logo192.png" alt="packets" />
    <h3>Packets</h3>
  </div>
  <div className="item">
    <img src="logo192.png" alt="bottles" />
    <h3>Bottles</h3>
  </div>
  <div className="item">
    <img src="logo192.png" alt="tins" />
    <h3>Tins</h3>
  </div>
</div>

    );
};

export default Miniproduct;