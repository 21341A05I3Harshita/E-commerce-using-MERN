import React from 'react';
import About from './about';
import Services from './servieces';
import Contact from './contact';
import Footer from './footer';
import { Animatorpage2 } from "./animatorpage";

const App = () => {
  return (
    <div style={{ marginTop: "90px" }}>
      <Animatorpage2>
        <div style={{
          
          position: "relative",
          height: "90vh",
          display: "flex",
        }}>
          <div style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: "url('/homepage/main_img2.png')",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center",
            opacity: 0.8,
            zIndex: 1
          }}></div>

          <div style={{
            position: "relative",
            display: "flex",
            width: "100%",
            zIndex: 2
          }}>
            <div style={{
              margin: "auto",
              height: "50vh",
              width: "70vh",
              display: "flex",
              flexDirection: "column",
              backgroundColor: "white",
              padding: "20px",
              boxSizing: "border-box",
              background: "transparent",
              gap: "50px"
            }}>
              <p style={{ color: "darkblue", fontSize: "30px" }}>Understand the importance of water</p>
              <h1 style={{ fontSize: "50px", color: "black" }}>
                Pure & Healthy Drink
                <br />
                Water You Think
              </h1>
              <p style={{ color: "darkblue", fontSize: "20px" }}>Drinking water! It's essential for human survival, and thank best life you must fully most of us have easy access to it this is very.</p>
            </div>
            <div style={{
              margin: "auto",
              height: "60vh",
              width: "50vh",
              backgroundRepeat: "no-repeat",
              borderRadius: "90px",
              backgroundImage: "url('logo1.png')"
            }}></div>
          </div>
        </div>
      </Animatorpage2>
      <Services />
      <About />
      <Contact />
      <Footer />
      
    </div>
  );
};

export default App;
