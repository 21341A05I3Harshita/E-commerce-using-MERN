import React from 'react';
import { Box } from '@mui/material';
import './About.css';
import {  motion } from "framer-motion";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import Footer from './footer';
const animations1 = {
    initial: { opacity: 0, x: 100 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -100 }
};
const About1 = () => {

    return (
        <>
        <Box
                    sx={{
                        backgroundImage: "url('/productpage/product_image.png')",
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "100% 100%",
                        width: "100%",
                        height: "50vh",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "white",
                        textAlign: "center",
                        marginTop:"100px"
                    }}
                >
                    <h1 style={{ fontSize: "3rem", fontWeight: "bold", margin: "0",color:"white"}}>About</h1>
                    <p style={{ fontSize: "1.2rem", marginTop: "10px",color:"white" }}>home / About</p>
                </Box>
        <motion.div className="about-container"
        variants={animations1}
        initial="initial"
        whileInView="animate"
        exit="exit"
        viewport={{amount:0.2}}
        transition={{duration:1}}>
            <img className='about-image' src="about.png" alt="about logo"/>
            <div className='about-info'>
                <p style={{color:"darkblue",fontSize:"20px"}}>About us</p>
                <h1 style={{color:"black",fontSize:"50px"}}>Safe Water Is Essential<br></br> For Our Healthy Life</h1>
                <p>We know that as water is the most essential element for all living <br></br>
                beings, not only humans, and you have to take it regularly, you are<br></br>
                efer searching for the best .</p>
                <h3><CheckCircleIcon style={{ color: '#65A5BA' }}/>The customer is very happy      <CheckCircleIcon style={{ color: '#65A5BA' }}/>Adipiscing will follow</h3>
                <h3><CheckCircleIcon style={{ color: '#65A5BA' }}/>Contrary to popular belief      <CheckCircleIcon style={{ color: '#65A5BA' }}/>To come to the smallest detail</h3>
            </div>
        </motion.div>
        <h1 style={{textAlign:"center",marginBottom:"60px"}}>OUR TEAM</h1>
        <div style={{ width: "100%", display: "flex", justifyContent: "center", gap: "20px", flexWrap: "wrap" ,marginBottom:"100px"}}>
            
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": {backgroundColor:"#65A5BA",opacity:".5", transform: "scale(1.02)" } }}>
                            <img src="" alt="harshitha" style={{ width: "100%", height: "300px", }} />
                        </Box>
                        <Box   sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { backgroundColor:"#65A5BA",opacity:".5",transform: "scale(1.02)" } }}>
                            <img src="" alt="satwika" style={{ width: "100%", height: "300px", }} />
                        </Box>
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { backgroundColor:"#65A5BA",opacity:".5",transform: "scale(1.02)" } }}>
                            <img src="" alt="kishore" style={{ width: "100%", height: "300px", }} />      
                        </Box>
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { backgroundColor:"#65A5BA",opacity:".5",transform: "scale(1.02)" } }}>
                            <img src="" alt="Abhi Ram" style={{ width: "100%", height: "300px", }} />      
                        </Box>
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { backgroundColor:"#65A5BA",opacity:".5",transform: "scale(1.02)" } }}>
                            <img src="" alt="Yashwanth" style={{ width: "100%", height: "300px", }} />      
                        </Box>
                        <Box  sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { backgroundColor:"#65A5BA",opacity:".5",transform: "scale(1.02)" } }}>
                            <img src="" alt="Appalanaidu" style={{ width: "100%", height: "300px", }} />      
                        </Box>
                    </div>
        <Footer/>
        
        </>
    );
};

export default About1;
