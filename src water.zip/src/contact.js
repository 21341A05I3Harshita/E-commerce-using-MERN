import React from 'react';
import './Contact.css';  // Assuming you're using a CSS file for styling
import { Button, TextField } from '@mui/material';
import {  motion } from "framer-motion";
const animations1 = {
    initial: { opacity: 0, x: -100 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 100 }
};

const Contact = () => {
    

    return (
        <motion.div
        variants={animations1}
        initial="initial"
        whileInView="animate"
        exit="exit"
        viewport={{amount:0.2}}
        transition={{duration:1}}
        className="contact-container">
           <div className='contact-info'>
            <p style={{fontSize:"20px" ,marginLeft:"20%"}}>To Communication</p>
            <h1 style={{marginLeft:"20%"}}>Please Email The Answers
            To Your Questions</h1>
            <form className='contact-form' style={{marginLeft:"20%",}}>
                <div style={{display:"flex",gap:"20px"}}>
                <TextField
                name='contact-name'
                label='name'
                type='text'
                variant='outlined'
                />
                <TextField
                name='contact-name'
                label='phone'
                type='tele'
                variant='outlined'
                />
                </div>
                <div style={{display:"flex",gap:"20px"}}>
                <TextField
                name='contact-name'
                label='email'
                type='email'
                variant='outlined'
                />
               <TextField
                name='contact-name'
                label='serviece need'
                type='text'
                variant='outlined'
                />
                </div>
                <TextField
                name="contact-name"
                label="Your message"
                type="text"
                variant="outlined"
                style={{ width: '73%' }}
                multiline
                rows={4} // Controls the height of the multiline input
                />
                <Button  variant='contained'
                type='submit'
                className="signup-button" 
                label="submit" 
                style={{
                    background: '#65A5BA',
                    borderRadius: '25px',
                    width:"30%",
                    color:"white"}}>
                        submit
                </Button>

            </form>
           </div>
           <img className="contact-img" src="contact.png" alt="contact-image"/>
        </motion.div>
        
    );
};

export default Contact;
