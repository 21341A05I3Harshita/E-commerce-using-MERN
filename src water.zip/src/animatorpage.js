import React from "react";
import { motion } from 'framer-motion';

const animations1 = {
    initial: { opacity: 0, x: 100 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -100 }
};

const animations2 = {
    initial: { opacity: 0, y: 100 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -100 }
};

const animations3 = {
    initial: { opacity: 0, y: -100 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 100 }
};

export const Animatorpage1 = ({ children }) => {
    return (
        <motion.div
            variants={animations1}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={{ duration: 3 }}
            style={{ display: 'block' }}
        >
            {children}
        </motion.div>
    );
};

export const Animatorpage2 = ({ children }) => {
    return (
        <motion.div
            variants={animations2}
            initial="initial"
            animate="animate"
            exit="exit"
            whileInView="animate"
            viewport={{ margin:"-200px", once:true}}
            transition={{ duration: 1 }}
        >
            {children}
        </motion.div>
    );
};

export const Animatorpage3 = ({ children }) => {
    return (
        <motion.div
            variants={animations3}
            initial="initial"
            animate="animate"
            exit="exit"
            whileInView="animate"
            viewport={{ margin:"-200px", once:true}}
            transition={{ duration: 1 }}
        >
            {children}
        </motion.div>
    );
};
