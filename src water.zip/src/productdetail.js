import React from "react";
import { useParams,useNavigate } from "react-router-dom";
import { Typography, Box, Button, TextField } from "@mui/material";
import Footer from "./footer";
import axios from "axios";


const products = [
    { id: 1, name: "250ml packet", price: "5.0/-", alt: "250ml packet", imageUrl: "/products/packets/pack250ml.png" },
    { id: 2, name: "350ml packet", price: "7.0/-", alt: "350ml packet", imageUrl: "/products/packets/pack350ml.png" },
    { id: 3, name: "500ml packet", price: "10.0/-", alt: "500ml packet", imageUrl: "/products/packets/pack500ml.png" },
    { id: 4, name: "250ml bottle", price: "5.0/-", alt: "250ml bottle", imageUrl: "/products/bottles/250ml.png" },
    { id: 5, name: "1L bottle", price: "10.0/-", alt: "1L bottle", imageUrl: "/products/bottles/1000ml.png" },
    { id: 6, name: "2L bottle", price: "20.0/-", alt: "2L bottle", imageUrl: "/products/bottles/2000ml.png" },
    { id: 7, name: "20L can", price: "25.0/-", alt: "20L can", imageUrl: "/products/can/20lit.png" }
];

const ProductDetails = () => {
    const navigate = useNavigate();

  const handleProductClick=(id)=>{
    navigate(`/products/${id}`);
  }
    const { id } = useParams();
    const product = products.find((item) => item.id === parseInt(id));

    if (!product) return <p>Product not found!</p>;

    const handleAdc = () => {
      const quantity = document.getElementById("quan").value;
      const user = JSON.parse(localStorage.getItem('user'));
      const userid = user && user.id ? user.id : null;
  
      if (!userid) {
          alert("User ID not found. Please log in.");
          return;
      }

      if(quantity > 0) {
      const data = {
          user_id: userid,
          product_name: product.name,
          product_cost: product.price,
          product_quantity: quantity
      };
  
      axios.post('http://localhost:8081/ADC', data)
          .then((response) => {
              if (response.status === 201) {
                  alert("Item added to cart successfully");
              }
          })
          .catch((error) => {
              console.error("Error adding to cart:", error);
              alert("Failed to add item to cart.");
          });
        }
        else {
          alert("enter correct quantity");
        }
  };

  const handleProductClick1 = (product) => {
    const quantity = document.getElementById("quan").value;
    if (quantity <= 0 || quantity === undefined) {
        alert("Please enter correct quantity");
    } else { 
        navigate('/placingorder', {
            state: {
                product:product,
                quantity:quantity,
                frompage:'products'
            },
        });
    }
};



  

    return (
        <div style={{ marginTop: "100px" }}>
            <Box
                sx={{
                    backgroundImage: "url('/productpage/product_image.png')",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "100% 100%",
                    width: "100%",
                    height: "50vh",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    textAlign: "center",
                }}
            >
                <h1 style={{ fontSize: "3rem", fontWeight: "bold", margin: "0", color: "white" }}>Products</h1>
                <p style={{ fontSize: "1.2rem", marginTop: "10px", color: "white" }}>home / product</p>
            </Box>

            <div style={{ width: "100%", display: "flex", justifyContent: "center", gap: "20px", flexWrap: "wrap" }}>
                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        marginTop: "90px",
                        boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                        marginBottom: "90px",
                        position: "relative",
                    }}
                >
                    <img src={product.imageUrl} alt={product.name} style={{ width: "300px", height: "400px", marginBottom: "20px" }} />
                    <Typography variant="h4" fontWeight="bold">{product.name}</Typography>
                    <Typography variant="h5" color="text.secondary" sx={{ marginBottom: "20px" }}>{product.price}/-</Typography>
                    <TextField type="number" variant="outlined" id="quan" />
                    <Button onClick={handleAdc} variant="contained" color="primary" sx={{ marginBottom: "10px", backgroundColor: "#65A5BA", '&:hover': { backgroundColor: "#3F6E7D" } }}>Add to Cart</Button>
                    <Button onClick={()=>handleProductClick1(product)} variant="contained" color="secondary" sx={{ backgroundColor: "#65A5BA", '&:hover': { backgroundColor: "#3F6E7D" } }}>Buy Now</Button>
                </Box>
                </div>
                <table style={{margin:"auto" }}>
                    <tr>
                    <th>
                        <Box onClick={()=>handleProductClick(1)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/packets/pack250ml.png" alt="250ml packet" style={{ width: "100%", height: "300px", }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>5.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>250ml packet</p>
                            
                        </Box>
                        </th>
                        <th>
                        <Box onClick={()=>handleProductClick(2)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/packets/pack350ml.png" alt="350ml packet" style={{ width: "100%", height: "300px", }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>7.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>350ml packet</p>
                             
                        </Box>
                        </th>
                        <th>
                        <Box onClick={()=>handleProductClick(3)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/packets/pack500ml.png" alt="500ml packet" style={{ width: "100%", height: "300px", }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>10.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>500ml packet</p>
                            
                             
                        </Box>
                   </th>
                   <th>
                   
                        <Box onClick={()=>handleProductClick(4)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/bottles/250ml.png" alt="250ml bottle" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>5.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>250ml bottle</p>
                            
                             
                        </Box>
                        </th>
                        <th>
                        <Box onClick={()=>handleProductClick(5)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/bottles/1000ml.png" alt="1L bottle" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>10.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>1L bottle</p>
                            
                             
                        </Box>
                        </th>
                        <th>
                        <Box onClick={()=>handleProductClick(6)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/bottles/2000ml.png" alt="2L bottle" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>20.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>2L bottle</p>
                            
                             
                        </Box>
                        </th>
                        <th>
                        <Box onClick={()=>handleProductClick(7)} sx={{ width: "250px", padding: "20px", boxShadow:"0 2px 10px rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px", transition: ".3s", "&:hover": { transform: "scale(1.02)" } }}>
                            <img src="/products/can/20lit.png" alt="250ml packet" style={{ width: "100%", height: "300px",  }} />
                            <Box sx={{ fontSize: "1.5rem", letterSpacing: "1px", fontWeight: "bold", width: "75%", textAlign: "center", padding: "5px", transition: ".3s", "&:hover": { backgroundColor: "black", color: "white" } }}>25.0/-</Box>
                            <p style={{ fontSize: "1.5rem", fontWeight: "bold", textAlign: "center" }}>20lt can</p>
                             
                        </Box>
                        </th>
                        </tr>
                        </table>
                    
            
            <Footer />
        </div>
    );
};

export default ProductDetails;
