import { TextField, Button,Typography } from '@mui/material';
import axios from 'axios';
import React, { useState } from 'react';
import './signup.css'; 
import {Animatorpage1} from './animatorpage';
import { Link } from "react-router-dom";
const Signup = () => {
  const [user, setUser] = useState({
    user_f_name: '',
    user_phone: '',
    user_email: '',
    user_password: '',
    user_confirm_password: ''
  });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  function handleChange(event) {
    const { name, value } = event.target; 
    setUser(prevState => ({
      ...prevState, [name]: value
    }));
  }

  function handleSubmit(event) {
    event.preventDefault();

    // Frontend validation
    if (!user.user_f_name || !user.user_phone || !user.user_email || !user.user_password || !user.user_confirm_password) {
      setError("All fields are required.");
      return;
    }

    if (user.user_password !== user.user_confirm_password) {
      setError("Passwords do not match.");
      return;
    }

    axios.post('http://localhost:8081/water', user)
      .then(res => {
        console.log("register success");
        setSuccess("User registered successfully!");
        setError(null);
      })
      .catch(err => {
        console.log("register failed", err);
        setError("Registration failed. Please try again.");
        setSuccess(null);
      });
  }

  return (
    <Animatorpage1>
    <div className="signup-container">
      <form onSubmit={handleSubmit} className="signup-form">
        <h1 className="signup-title">Sign Up</h1>

        {/* Display Success/Error messages */}
        {success && <p style={{ color: 'green' }}>{success}</p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}

        <div className="form-group">
          <TextField 
            name="user_f_name" 
            label="First Name" 
            variant="outlined" 
            onChange={handleChange}
            value={user.user_f_name}
          />
          <TextField 
            name="user_phone" 
            label="Phone" 
            variant="outlined"  
            onChange={handleChange}
            value={user.user_phone}
          />
        </div>
        
        <TextField 
          className='form-group'
          name="user_email" 
          label="Email" 
          variant="outlined"
          fullWidth
          onChange={handleChange}
          value={user.user_email}
        />
      
        <div className="form-group">
          <TextField 
            name="user_password" 
            label="Password" 
            type='password' 
            variant='outlined'
            onChange={handleChange}
            value={user.user_password}
          />
          <TextField 
            name="user_confirm_password" 
            label="Confirm Password" 
            type='password' 
            variant='outlined'
            onChange={handleChange}
            value={user.user_confirm_password}
          />
        </div>

        <Button
          variant='contained'
          type='submit'
          className="signup-button"
          style={{
            background: 'linear-gradient(90deg, #1E90FF 30%, #00BFFF 90%)',
            borderRadius: '25px',
            padding: '10px 0',
            marginTop: '20px',
          }}
        >
          Submit
        </Button>

        <Link to='/login' style={{textAlign:"center", textDecoration: "none", color: "blue" }}>
            <Typography variant="body1">already have an account?</Typography>
          </Link>
      </form>
      <img 
        className="signup-background"
        src='https://img.freepik.com/free-photo/realistic-water-drop-with-ecosystem_23-2151196402.jpg' 
        alt="background"
      />
    </div>
    </Animatorpage1>
  );
};

export default Signup;
