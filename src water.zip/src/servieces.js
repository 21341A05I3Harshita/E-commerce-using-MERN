import React from "react";
import './servieces.css';

import { motion } from 'framer-motion';
const animations2 = {
    initial: { opacity: 0, y: 100 },
    animate: { opacity: 1, y: -50 },
    exit: { opacity: 0, y: -100 }
};
const animations3 = {
    initial: { opacity: 0, y: -100 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 100 }
};
function Services() {
    

    
    return (
        <div className="services-container" style={{
            marginTop: "200px",
            
            height: "90vh",
            width: "auto",
            display: "flex",
            flexDirection: "column",
            gap: "30px",
            alignItems: "center"
        }}>
            <motion.div
            variants={animations2}
            initial="initial"
            whileInView="animate" // Triggers the animation when in view
            exit="exit"
            viewport={{ amount: 1 }} // Triggers when the entire component is in view
            transition={{ duration: 1 }} // Duration of the animation
            >

                <p style={{ color: "darkblue", fontSize: "30px", textAlign: "center" }}>Our Services</p>
                <h1 style={{
                    fontSize: "60px",
                    textAlign: "center"
                }}>
                    The AQUA DROP
                    <br />A Safe Haven
                </h1>
            </motion.div>
            <motion.div
            variants={animations3}
            initial="initial"
            whileInView="animate" // Triggers the animation when in view
            exit="exit"
            viewport={{ amount: 1 }} // Triggers when the entire component is in view
            transition={{ duration: 1 }} // Duration of the animation
            >
                {/* First Row of Services */}
                <div style={{
                    height: "30vh",
                    width: "140vh",
                    display: "flex",
                    justifyContent: "space-around"
                }}>
                    <div className="service-box" style={{
                        height: "30vh",
                        width: "68vh",
                        display: "flex",
                        alignItems: "center"
                    }}>
                        <img className="ser-img" src="ser1.png" alt="logo1" style={{
                            height: "30vh",
                            width: "40vh"
                        }} />
                        <div className="service-description">
                            <h2>Maximum Purification</h2>
                            <p>
                                The client himself is important,<br />
                                he is the client of the client,<br />
                                but I do the same thing as a contributor<br />
                                like a client user of that.
                            </p>
                        </div>
                    </div>
                    <div className="service-box" style={{
                        height: "30vh",
                        width: "68vh",
                        display: "flex",
                        alignItems: "center"
                    }}>
                        <img className="ser-img" src="ser2.png" alt="logo2" style={{
                            height: "30vh",
                            width: "40vh"
                        }} />
                        <div className="service-description">
                            <h2>Water Purified</h2>
                            <p>
                                The client is significant; after all,<br />
                                they are the customer of the client.<br />
                                However, I contribute in the same way,<br />
                                acting as a user for that client.
                            </p>
                        </div>
                    </div>
                </div>
                </motion.div>
                <motion.div
            variants={animations3}
            initial="initial"
            whileInView="animate" // Triggers the animation when in view
            exit="exit"
            viewport={{ amount: 1 }} // Triggers when the entire component is in view
            transition={{ duration: 1 }} // Duration of the animation
            >
                {/* Second Row of Services */}
                <div style={{
                    height: "30vh",
                    width: "140vh",
                    display: "flex",
                    justifyContent: "space-around"
                }}>
                    <div className="service-box" style={{
                        height: "30vh",
                        width: "68vh",
                        display: "flex",
                        alignItems: "center"
                    }}>
                        <img className="ser-img" src="ser3.png" alt="logo3" style={{
                            height: "30vh",
                            width: "40vh"
                        }} />
                        <div className="service-description">
                            <h2>Free Chlorine</h2>
                            <p>
                                It's important to recognize the client,<br />
                                who is essentially the customer's customer.<br />
                                Nevertheless, I fulfill a similar<br />
                                role as a contributor.
                            </p>
                        </div>
                    </div>
                    <div className="service-box" style={{
                        height: "30vh",
                        width: "68vh",
                        display: "flex",
                        alignItems: "center"
                    }}>
                        <img className="ser-img" src="ser4.png" alt="logo4" style={{
                            height: "30vh",
                            width: "40vh"
                        }} />
                        <div className="service-description">
                            <h2>Water Tank</h2>
                            <p>
                                It's important to recognize the client,<br />
                                who is essentially the customer's customer.<br />
                                Nevertheless, I fulfill a similar<br />
                                role as a contributor.
                            </p>
                        </div>
                    </div>
                </div>
            </motion.div>
        </div>
    );
}

export default Services;
