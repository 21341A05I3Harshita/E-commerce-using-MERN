import { TextField, Button,  Typography } from '@mui/material';
import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import GoogleIcon from '@mui/icons-material/Google';
import FacebookIcon from '@mui/icons-material/Facebook';
import './login.css'; // Your custom CSS
import {Animatorpage1} from './animatorpage';

const Login = () => {
  const [user_phone, setUser_phone] = useState('');
  const [user_password, setUser_password] = useState('');

  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  function handleSubmit1(event) {
    event.preventDefault();

    setErrorMessage('');

    // Basic validation
    if (!user_phone || !user_password) {
      setErrorMessage('Please enter both phone and password');

      return;
    }

    const requestBody = {
      login_phone_input: user_phone,
      login_password_input: user_password,
    };

    console.log("Request Body (Login):", requestBody); // Log the request body

    axios.post('http://localhost:8081/login', requestBody)
      .then((response) => {
        if (response.status === 200) {
          const userData=response.data.user;
          localStorage.setItem('user', JSON.stringify(userData));
          alert('Login successful');
          
          navigate('/app'); // Redirect to the appropriate page
          window.location.reload();
          
        }
      })
      .catch((error) => {

        if (error.response && error.response.status === 401) {
          setErrorMessage('Invalid phone number or password');
        } else if (error.response && error.response.status === 400) {
          setErrorMessage('Bad request, please check your inputs');
        } else {
          setErrorMessage('Login error, please try again later');
        }
      });
  }

  return (
    <Animatorpage1>
      <div className="login-container">
        <img className="login-image1" src='https://img.freepik.com/free-photo/realistic-water-drop-with-ecosystem_23-2151196402.jpg' alt="Login Visual" />
        
        <form onSubmit={handleSubmit1} className="login-form">
          <h2 className="login-title">Sign in</h2>

          <TextField
            name="login_phone_input" 
            type="tel"
            label="Phone"
            variant="outlined"
            value={user_phone}
            onChange={(e) => setUser_phone(e.target.value)}
            fullWidth
            margin="normal"
          />
          <TextField
            name="login_password_input"
            type="password"
            label="Password"
            variant="outlined"
            value={user_password}
            onChange={(e) => setUser_password(e.target.value)}
            fullWidth
            margin="normal"
          />

          {errorMessage && (
            <Typography color="error" style={{ textAlign: 'center' }}>
              {errorMessage}
            </Typography>
          )}

          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            style={{
              background: 'linear-gradient(90deg, #1E90FF 30%, #00BFFF 90%)',
              borderRadius: '25px',
              padding: '10px 0',
              marginTop: '20px',
              marginBottom: '20px',
            }}
            
          >
            login
          </Button>

          <Link to='/signup' style={{ textDecoration: "none", color: "blue" }}>
            <Typography variant="body1">Register</Typography>
          </Link>

          <div className="social-login">
            <Button
              variant="outlined"
              startIcon={<GoogleIcon />}
              fullWidth
              style={{ marginBottom: '10px', borderRadius: '25px' }}
            >
              Sign in with Google
            </Button>

            <Button
              variant="outlined"
              startIcon={<FacebookIcon />}
              fullWidth
              style={{ borderRadius: '25px' }}
            >
              Sign in with Facebook
            </Button>
          </div>
        </form>
      </div>
    </Animatorpage1>
  );
};

export default Login;
