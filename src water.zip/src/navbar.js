import { AppBar, Toolbar, Typography, Box, Button, Menu, MenuItem, Table, TableCell, TableRow, TextField, TableBody } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from 'react-router-dom';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import BackpackIcon from '@mui/icons-material/Backpack';
import axios from "axios";
const Navbar = () => {
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem('user'));
    const [anchorEl, setAnchorEl] = useState(null); // Initialize anchorEl as null for menu
    const [anchorEl1, setAnchorEl1] = useState(null);
    const [anchorEl2, setAnchorEl2] = useState(null);
    const value = user.id;
    const [adcValue,setAdcValue] = useState(null);
    const [editMode,setEditMode] = useState(null);
    const [user_name,setUser_name] = useState(null);
    const [user_email,setUser_email] = useState(null);
    const [user_phone,setUser_phone] = useState(null);
    const [cartItems,setCartItems]=useState([]);
    useEffect(() => {
        const fetch_data = async () => {
            try {
                const response = await axios.post('http://localhost:8081/ADCcount', { value });
                if (response.status === 200) { // Match with backend's status code
                    setAdcValue(response.data.count);
                }
            } catch (error) {
                console.error("Error fetching ADC count:", error);
            }
        };
        fetch_data();
    });

    const fetch_cartItems = async () => {
        try {
            const response = await axios.get('http://localhost:8081/GetAddCart');
            setCartItems(response.data); // Update state with the fetched data
        } catch (error) {
            console.log("Error fetching data:", error);
        }
    };

    const cartItemsElements = [];
    cartItems.forEach((item, index) => {
        cartItemsElements.push(
            <TableRow key={index}>
                <TableCell>{item.product_name}</TableCell>
                <TableCell>{item.product_quantity}</TableCell>
                <TableCell>{item.product_cost}</TableCell>
                <TableCell><Button onClick={()=>{handleBuyNow(item)}} sx={{color:"black",transition:".5s","&:hover":{color:"white",backgroundColor:"black"}}}>buy now</Button></TableCell>
                <TableCell><Button onClick={()=>{handleRemove(item)}} sx={{color:"black",transition:".5s","&:hover":{color:"white",backgroundColor:"black"}}}>remove</Button></TableCell>
            </TableRow>
        );
    });
    
    const handleBuyNow = (item) => {
        handleRemove(item);
        navigate('/placingorder',{state:{product:item,quantity:item.product_quantity}
        });

    };

    const handleRemove = (item) => {
        const requestBody ={
            user_id:user.id,
            product_name:item.product_name,
            product_cost:item.product_cost,
            product_quantity:item.product_quantity
        };
        axios.post('http://localhost:8081/remove_ADC',requestBody)
        .then((response)=>{
            if(response.status===200){
                alert('item removed successfully');
                const updatecartItmes = cartItems.filter(cartItem=>cartItem.product_name !== item.product_name )
                setCartItems(updatecartItmes);
            }
        })
        .catch((error)=>{
            console.log(error);
        });

    };

    const handleEditDetails = () => {
        const requestBody = {
            user_name: user_name,
            user_phone: user_phone,
            user_email: user_email,
            user_id: user.id
        };
    
        axios.post('http://localhost:8081/EditDetails', requestBody)
            .then((response) => {
                if (response.status === 200) {
                    console.log("User details updated successfully.");
                    localStorage.setItem('user', JSON.stringify({ ...user, name: user_name, phone: user_phone, email: user_email }));
                    setEditMode(false);
                }
            })
            .catch((error) => {
                console.error("Error updating user details:", error);
            });
    };
    
    

    // Function to handle menu opening
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClick1 = (event) => {
        setAnchorEl1(event.currentTarget);
    };
    const handleClick2 = (event) => {
        setAnchorEl2(event.currentTarget);
        fetch_cartItems();
    };

    // Function to handle logout
    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/'); // Redirect to home
        window.location.reload(); // Reload the page
    };

    // Function to close the menu
    const handleClose = () => {
        setAnchorEl(null);
    };
    const handleClose1 = () => {
        setAnchorEl1(null);
    };
    const handleClose2 = () => {
        setAnchorEl2(null);
    };
    

    return (
        <AppBar position="fixed" color="default" sx={{ backgroundColor: "white", boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.1)" }}>
            <Toolbar sx={{ justifyContent: "space-between", paddingX: "16px" }}>
                <Box component="img" src="logo1.png" alt="logo" sx={{ width: "90px", height: "auto", cursor: "pointer" }} />
                <Box sx={{ display: "flex", gap: "30px", flexGrow: 1, justifyContent: "flex-start" }}>
                    <Link to="/App" style={{textDecoration:"none"}}>
                    <Typography variant="body1" sx={{ cursor: "pointer", fontSize: "25px", color: "black", "&:hover": { color: "primary.main", transform: "scale(1.05)", transition: ".3s" } }} onClick={()=>navigate('/app')}>
                        Home
                    </Typography>
                    </Link>
                    <Link to="/about1" style={{textDecoration:"none"}}>
                    <Typography variant="body1" sx={{ cursor: "pointer", fontSize: "25px", color: "black", "&:hover": { color: "primary.main", transform: "scale(1.05)", transition: ".3s" } }} onClick={() => navigate('/about1')}>
                        About
                    </Typography>
                    </Link>
                    <Link to="/servieces1" style={{textDecoration:"none"}}>
                    <Typography variant="body1" sx={{ cursor: "pointer", fontSize: "25px", color: "black", "&:hover": { color: "primary.main", transform: "scale(1.05)", transition: ".3s" } }} onClick={() => navigate('/servieces1')}>
                        Services
                    </Typography>
                    </Link>
                    <Link to="/contact1" style={{textDecoration:"none"}}>
                    <Typography variant="body1" sx={{ cursor: "pointer", fontSize: "25px", color: "black", "&:hover": { color: "primary.main", transform: "scale(1.05)", transition: ".3s" } }} onClick={() => navigate('/contact1')}>
                        Contact
                    </Typography>
                    </Link>
                    <Box onMouseEnter={handleClick} onMouseLeave={handleClose} style={{ position: "relative" }}>
                        <Typography
                            variant="body1"
                            sx={{ cursor: "pointer", fontSize: "25px", color: "black", "&:hover": { color: "primary.main", transform: "scale(1.05)", transition: ".3s" } }}
                        >
                            <span>Products</span> {/* Use span to trigger the menu */}
                        </Typography>
                        <Menu
                            anchorEl={anchorEl}
                            open={Boolean(anchorEl)}
                            onClose={handleClose}
                            sx={{ display: "flex", padding: "8px", flexDirection: "row" }}
                        >
                            <MenuItem
                                onClick={() => {
                                    navigate('/products'); // Close the menu
                                    // Logic for packets can go here
                                }}
                                style={{ display: "inline-block", backgroundColor: "#FFFFF", borderRadius: "0 4px 8px rgba(0,0,0,0.1)" }}
                            >
                                <Box sx={{ alignItems: "center", display: "flex", flexDirection: "column" }}>
                                    <img src="logo1.png" alt="packets" style={{ width: "auto", height: "90px" }} />
                                    <p>All Products</p>
                                </Box>
                            </MenuItem>
                            <MenuItem
                                onClick={() => {
                                    navigate('/productbottles') // Close the menu
                                    // Logic for packets can go here
                                }}
                                style={{ display: "inline-block", backgroundColor: "#FFFFF", borderRadius: "0 4px 8px rgba(0,0,0,0.1)" }}
                            >
                                <Box sx={{ alignItems: "center", display: "flex", flexDirection: "column" }}>
                                    <img src="logo1.png" alt="packets" style={{ width: "auto", height: "90px" }} />
                                    <p>bottles</p>
                                </Box>
                            </MenuItem>
                            <MenuItem
                                onClick={() => {
                                    navigate('/productpackets') // Close the menu
                                    // Logic for bottles can go here
                                }}
                                style={{ display: "inline-block", backgroundColor: "#FFFFF", borderRadius: "0 4px 8px rgba(0,0,0,0.1)" }}
                            >
                                <Box sx={{ alignItems: "center", display: "flex", flexDirection: "column" }}>
                                    <img src="logo1.png" alt="bottles" style={{ width: "auto", height: "90px" }} />
                                    <p>packets</p>
                                </Box>
                            </MenuItem>
                            <MenuItem
                                onClick={() => {
                                    navigate('/productcan'); // Close the menu
                                    // Logic for cans can go here
                                }}
                                style={{ display: "inline-block", backgroundColor: "#FFFFF", borderRadius: "0 4px 8px rgba(0,0,0,0.1)" }}
                            >
                                <Box sx={{ alignItems: "center", display: "flex", flexDirection: "column" }}>
                                    <img src="logo1.png" alt="cans" style={{ width: "auto", height: "90px" }} />
                                    <p>cans</p>
                                </Box>
                            </MenuItem>
                        </Menu>
                    </Box>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: "16px" }}>
                    <AccountCircleIcon sx={{ color: "#173058",width: "70px",height:"auto" ,transition:".5s","&:hover":{color:"#65A5BA"}}} onClick={handleClick1} />
                    <Menu anchorEl={anchorEl1} open={Boolean(anchorEl1)} onClose={handleClose1}>
            <MenuItem sx={{ p: 0 }}> {/* Remove default padding */}
                <Box
                    sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        padding: '24px',
                        backgroundColor: 'white',
                        borderRadius: '12px',
                        width: '300px',
                        boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
                        border: '1px solid #e0e0e0',
                        justifyContent: 'center',
                        alignItems: "center"
                    }}
                >
                    <Typography variant="h6" color="text.primary" fontWeight="bold" gutterBottom>
                        Profile
                    </Typography>
                    
                    {editMode ? (
                        <Box
                        sx={{display:"flex",flexDirection:"column"}}>
                            <TextField
                                variant="outlined" // Corrected variant typo
                                label="Name"
                                required="true"
                                onChange={(e) => setUser_name(e.target.value)} 
                                name="nav_user_name"
                                margin="normal"
                                fullWidth
                            />
                            <TextField
                                variant="outlined" // Corrected variant typo
                                label="Phone"
                                required="true"
                                onChange={(e) => setUser_phone(e.target.value)}
                                name="nav_user_phone"
                                margin="normal"
                                fullWidth
                            />
                            <TextField
                                variant="outlined" // Corrected variant typo
                                label="Email"
                                required="true"
                                onChange={(e) => setUser_email(e.target.value)}
                                name="nav_user_email"
                                margin="normal"
                                fullWidth
                            />
                            <Button
                                variant="contained"
                                onClick={() => handleEditDetails()} // Add functionality to exit edit mode
                                sx={{
                                    color: "black",
                                    backgroundColor: "white",
                                    '&:hover': {
                                        backgroundColor: 'black',
                                        color: 'white',
                                    },
                                    mt: 2
                                }}
                            >
                                Save
                            </Button>
                            <Button
                                variant="contained"
                                onClick={() => setEditMode(false)} // Add functionality to exit edit mode
                                sx={{
                                    color: "black",
                                    backgroundColor: "white",
                                    '&:hover': {
                                        backgroundColor: 'black',
                                        color: 'white',
                                    },
                                    mt: 2
                                }}
                            >
                                cancel
                            </Button>
                        </Box>
                    ) : (
                        <Table sx={{ width: "100%", borderCollapse: "collapse", margin: "20px 0" }}>
                        <TableRow sx={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #dee2e6" }}>
                          <TableCell sx={{ padding: "12px 15px", fontSize: "16px", fontWeight: "bold", color: "#555" }}>
                            Name:
                          </TableCell>
                          <TableCell sx={{ padding: "12px 15px", fontSize: "16px", color: "#333" }}>
                            {user.name}
                          </TableCell>
                        </TableRow>
                        <TableRow sx={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #dee2e6" }}>
                          <TableCell sx={{ padding: "12px 15px", fontSize: "16px", fontWeight: "bold", color: "#555" }}>
                            Phone:
                          </TableCell>
                          <TableCell sx={{ padding: "12px 15px", fontSize: "16px", color: "#333" }}>
                            {user.phone}
                          </TableCell>
                        </TableRow>
                        <TableRow sx={{ backgroundColor: "#f8f9fa", borderBottom: "1px solid #dee2e6" }}>
                          <TableCell sx={{ padding: "12px 15px", fontSize: "16px", fontWeight: "bold", color: "#555" }}>
                            Email:
                          </TableCell>
                          <TableCell sx={{ padding: "12px 15px", fontSize: "16px", color: "#333" }}>
                            {user.email}
                          </TableCell>
                        </TableRow>
                      </Table>
                    )}
                    
                    {!editMode && (
                        <Button
                            variant="outlined"
                            onClick={() => setEditMode(true)} // Toggle edit mode
                            sx={{
                                color: 'black',
                                borderColor: 'black',
                                '&:hover': {
                                    backgroundColor: 'black',
                                    color: 'white',
                                    borderColor: 'black',
                                },
                                mt: 2
                            }}
                        >
                            Edit
                        </Button>
                    )}
                     <Button
                            variant="outlined"
                            onClick={() => navigate('/orders')} // Toggle edit mode
                            sx={{
                                color: 'black',
                                borderColor: 'black',
                                '&:hover': {
                                    backgroundColor: 'black',
                                    color: 'white',
                                    borderColor: 'black',
                                },
                                mt: 2
                            }}
                        >
                            your orders
                        </Button>
                </Box>
            </MenuItem>
        </Menu>

<Typography >
<BackpackIcon onClick={handleClick2} sx={{ color: "#173058", width: "70px", height: "auto",position:"relative",transition:".5s","&:hover":{color:"#65A5BA"} }} />
<span style={{position: "absolute",top: "50%",right: "7%",backgroundColor: "red",borderRadius: "50%",fontSize: "20px",padding: "4px 8px",color: "white",textAlign: "center",lineHeight: "20px"}}>
  {adcValue!==null ? adcValue:0}
</span>

<Menu anchorEl={anchorEl2} open={Boolean(anchorEl2)} onClose={handleClose2}>
{cartItems.length > 0 ?(
    <MenuItem>
    <Box>
    <Table sx={{ width: '100%', border: '1px solid #ddd', marginBottom: '20px' }}>
    <TableBody>
        <TableRow sx={{ backgroundColor: '#f5f5f5', fontWeight: 'bold' }}>
            <TableCell sx={{ padding: '8px', textAlign: 'center' }}>Name</TableCell>
            <TableCell sx={{ padding: '8px', textAlign: 'center' }}>Quantity</TableCell>
            <TableCell sx={{ padding: '8px', textAlign: 'center' }}>Cost</TableCell>
        </TableRow>
        {cartItemsElements}
    </TableBody>
</Table>

    </Box>
    </MenuItem>

):(
    <MenuItem>
    <Box>
        no items in cart
    </Box>
    </MenuItem>
)}
</Menu>

    </Typography>
                    
                    <Button
                        variant="outlined"
                        onClick={handleLogout}
                        sx={{ borderColor: "primary.main", color: "primary.main", "&:hover": { backgroundColor: "primary.main", color: "white" } }}
                    >
                        Logout
                    </Button>
                </Box>
            </Toolbar>
        </AppBar>
    );
};

export default Navbar;
