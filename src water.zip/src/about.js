import React from 'react';
import './About.css';
import {  motion } from "framer-motion";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
const animations1 = {
    initial: { opacity: 0, x: 100 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -100 }
};
const About = () => {

    return (
        
        <motion.div className="about-container"
        variants={animations1}
        initial="initial"
        whileInView="animate"
        exit="exit"
        viewport={{amount:0.2}}
        transition={{duration:1}}>
            <img className='about-image' src="about.png" alt="about logo"/>
            <div className='about-info'>
                <p style={{color:"darkblue",fontSize:"20px"}}>About us</p>
                <h1 style={{color:"black",fontSize:"50px"}}>Safe Water Is Essential<br></br> For Our Healthy Life</h1>
                <p>We know that as water is the most essential element for all living <br></br>
                beings, not only humans, and you have to take it regularly, you are<br></br>
                efer searching for the best .</p>
                <h3><CheckCircleIcon style={{ color: '#65A5BA' }}/>The customer is very happy      <CheckCircleIcon style={{ color: '#65A5BA' }}/>Adipiscing will follow</h3>
                <h3><CheckCircleIcon style={{ color: '#65A5BA' }}/>Contrary to popular belief      <CheckCircleIcon style={{ color: '#65A5BA' }}/>To come to the smallest detail</h3>
            </div>
        </motion.div>
        
    );
};

export default About;
