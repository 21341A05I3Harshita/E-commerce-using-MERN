import React from "react";
import { AppBar, Toolbar, Typography, Box} from "@mui/material";
const PlaceOrderNavbar = ()=>{
return(
    <AppBar position="fixed" color="default" sx={{ backgroundColor: "white", boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.1)" }}>
            <Toolbar sx={{ justifyContent: "space-between", paddingX: "16px" }}>
                <Box component="img" src="logo1.png" alt="logo" sx={{ width: "90px", height: "auto", cursor: "pointer" }} />
                <Box sx={{ display: "flex", gap: "30px", flexGrow: 1, justifyContent: "center" }}>
                    
                    <Typography variant="body1" sx={{ cursor: "pointer", fontSize: "25px", color: "black", "&:hover": { color: "primary.main", transform: "scale(1.05)", transition: ".3s" } }} >
                        Check out
                    </Typography>
                    
                   </Box>
            </Toolbar>
        </AppBar>

);
};

export default PlaceOrderNavbar;