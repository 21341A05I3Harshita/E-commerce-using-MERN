import { Table, TableCell, TableRow, TextField, Button } from '@mui/material';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from "react-router-dom";

const PlaceOrder = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { product, quantity,frompage } = state || {}; // Access the passed product
    const [address, setAddress] = useState('');
    const [district, setDistrict] = useState('srikakulam'); // Use state for district
    const [statename, setStatename] = useState('');
    const [postal , setPostal]=useState('');
    const [zipcode, setZipcode] = useState('');

    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based, so add 1
    const day = String(date.getDate()).padStart(2, '0');
    const order_date = `${year}-${month}-${day}`;
    let price;
    let name;
    
    useEffect(() => {
        if (zipcode.length === 6) {
          axios
            .get(`https://api.postalpincode.in/pincode/${zipcode}`)
            .then((response) => {
              const data = response.data[0]; // Response is an array, get the first object
              if (data.Status === "Success" && data.PostOffice && data.PostOffice.length > 0) {
                const firstPostOffice = data.PostOffice[0]; // Take the first post office
                setDistrict(firstPostOffice.District || "Unknown District");
                setStatename(firstPostOffice.State || "Unknown State");
                setPostal(firstPostOffice.Name || "Unknown Post Office");
                alert(""); // Clear any previous error
              } else {
                setDistrict("");
                setStatename("");
                
              }
            })
            .catch((error) => {
              console.error("Error fetching location details:", error);
              setDistrict("");
              setStatename("");
              
            });
        } else {
          setDistrict("");
          setStatename("");
          
        }
      }, [zipcode]);
    if (!product) { return <p>No product selected!</p>; }
    if(frompage === 'products'){
        price = parseFloat(product.price.replace('/-', ''));
        name = product.name;
    }
    else{
        price = parseFloat(product.product_cost);
        name = product.product_name;
    }
    const qty = parseInt(quantity);
    
    // Calculate GST outside of JSX
    const gst = price * qty * 0.20;
    const dis = price * qty * 0.10;
    const total = price * qty + gst - dis;

    const user = JSON.parse(localStorage.getItem('user'));  // Parse the user data from localStorage

   

    const handleSubmit = (e) => {
        e.preventDefault();  // Prevent the default form submission
        const id = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');

        const requestBody = {
            user_id: user.id,
            user_name: user.name,
            user_email: user.email,
            product_name: name,
            product_quantity: quantity,
            product_cost: total,
            user_zipcode:zipcode,
            user_state: statename,
            user_district: district,
            user_post:postal,
            user_address: address,
            date_order_placed: order_date,
            order_receieved: "not_yet_received",
            order_id:id 
        };

        axios.post('http://localhost:8081/placing_order', requestBody)
            .then((response) => {
                if (response.status === 200) {
                    alert("Order placed successfully");
                    navigate('/products');

                }
            })
            .catch((error) => {
                console.log("Error: " + error);
            });
    };

    return (
        <form onSubmit={handleSubmit} style={{
            marginTop: "100px",
            marginLeft: "auto",
            marginRight: "auto",
            width: "80%",
            height: "auto",
            display: "flex",
            flexDirection: "column",
            gap: "40px",
            padding: "20px",
            backgroundColor: "#f9f9f9",
            borderRadius: "8px",
            boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)"
        }}>
            <div style={{ paddingBottom: "10px" }}>
                <h2 style={{ fontSize: "24px", fontWeight: "600", color: "#333" }}>1. Order Details</h2>
                <Table>
                <TableRow style={{ fontWeight: "600" }}>
                    <TableCell>Product Name</TableCell>
                    <TableCell>Product Cost</TableCell>
                    <TableCell>Product Quantity</TableCell>
                    <TableCell>GST</TableCell>
                    <TableCell>Discount</TableCell>
                    <TableCell>Total</TableCell>
                </TableRow>
                {frompage === 'products' ? (
                <TableRow>
                    <TableCell>{product.name}</TableCell>
                    <TableCell>{product.price}</TableCell>
                    <TableCell>{quantity}</TableCell>
                    <TableCell>{gst}</TableCell>
                    <TableCell>{dis}</TableCell>
                    <TableCell>{total}</TableCell>
                </TableRow>
                ) : (
                <TableRow>
                    <TableCell>{product.product_name}</TableCell>
                    <TableCell>{product.product_cost}</TableCell>
                    <TableCell>{quantity}</TableCell>
                    <TableCell>{gst}</TableCell>
                    <TableCell>{dis}</TableCell>
                    <TableCell>{total}</TableCell>
                </TableRow>
                )}
                </Table>

            </div>
        
            <div style={{ paddingBottom: "10px" }}>
                <h2 style={{ fontSize: "24px", fontWeight: "600", color: "#333" }}>2. Address</h2>
                <div style={{
                    display: "flex",
                    gap: "20px",
                    flexDirection: "row",
                    marginBottom: "20px"
                }}>
                    <TextField
                        label="zip code"
                        onChange={(e)=>{setZipcode(e.target.value)}}
                        sx={{
                            maxWidth: "200px",
                            backgroundColor: "#fff",
                            borderRadius: "4px",
                            border: "1px solid #ddd",
                            padding: "10px"
                        }}
                    />
                    <TextField
                        value={statename}
                        InputProps={{readOnly:true}}
                        sx={{
                            maxWidth: "200px",
                            backgroundColor: "#fff",
                            borderRadius: "4px",
                            border: "1px solid #ddd",
                            padding: "10px"
                        }}
                    />
                    <TextField
                        
                        value={district}
                        inputProps={{ readOnly: true }}
                        sx={{
                            maxWidth: "200px",
                            backgroundColor: "#fff",
                            borderRadius: "4px",
                            border: "1px solid #ddd",
                            padding: "10px"
                        }}
                    />
                    <TextField
                        
                        value={postal}
                        inputProps={{ readOnly: true }}
                        sx={{
                            maxWidth: "200px",
                            backgroundColor: "#fff",
                            borderRadius: "4px",
                            border: "1px solid #ddd",
                            padding: "10px"
                        }}
                    />
                    <TextField
                        label="Address"
                        sx={{
                            maxWidth: "400px",
                            backgroundColor: "#fff",
                            borderRadius: "4px",
                            border: "1px solid #ddd",
                            padding: "10px"
                        }}
                        onChange={(e) => { setAddress(e.target.value) }}
                        required
                    />
                </div>
            </div>
        
            <div style={{ paddingBottom: "10px" }}>
                <h2 style={{ fontSize: "24px", fontWeight: "600", color: "#333" }}>3. Mode of Payment</h2>
                <label style={{ fontSize: "18px", color: "#333", display: "flex", alignItems: "center" }}>
                    <input
                        type="radio"
                        name="mode"
                        value="pay on delivery"
                        style={{ marginRight: "10px" }}
                        required
                    />
                    Pay on Delivery
                </label>
            </div>
        
            <div style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "30px"
            }}>
                <Button
                    type="submit"
                    variant='outlined'
                    sx={{
                        padding: "10px 30px",
                        fontSize: "16px",
                        "&:hover": {
                            backgroundColor: "lightblue",
                            color: "white"
                        }
                    }}
                >
                    Place Order
                </Button>
                <Button
                    variant='outlined'
                    onClick={() => navigate('/products')}
                    sx={{
                        padding: "10px 30px",
                        fontSize: "16px",
                        "&:hover": {
                            backgroundColor: "lightblue",
                            color: "white"
                        }
                    }}
                >
                    cancel Order
                </Button>
            </div>
        </form>
        
    );
};

export default PlaceOrder;
