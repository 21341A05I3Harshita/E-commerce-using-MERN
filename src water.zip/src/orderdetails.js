import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Box, Button, TextField } from "@mui/material";
import Footer from "./footer";
const OrderDetails=() => {
    const [otp,setotp] = useState('');
    const {orderId} = useParams();
    const [orderDetails,setOrderDetails]=useState('');
    useEffect(() =>{
        const fetch_OrderItems1= async()=>{
            try{
                const response = await axios.get(`http://localhost:8081/GetOrderDetails/${orderId}`);
                if(response.status===200) {
                    setOrderDetails(response.data);
                }
            }
            catch(e){
                console.log(e);
            }
        }
        fetch_OrderItems1();
    },[orderId]);

    const handleSubmit = () => {
        if (otp.trim().length === 0) {
            alert("Please fill your OTP");
        } else {
            const requestBody = {
                order_id: orderDetails.order_id,
                order_otp: otp
            };
    
            axios.post('http://localhost:8081/verifyotp', requestBody)
                .then((response) => {
                    if (response.status === 200 && response.data.message) {
                        alert(response.data.message); // Show message from backend
                    } else {
                        alert("Unexpected response from server.");
                    }
                })
                .catch((error) => {
                    if (error.response) {
                        // Backend returned an error response
                        alert(error.response.data.message || "An error occurred while verifying the OTP.");
                    } else if (error.request) {
                        // Request was made but no response received
                        alert("No response from server. Please try again later.");
                    } else {
                        // Something happened while setting up the request
                        alert("An unexpected error occurred. Please try again.");
                    }
                    console.error(error);
                });
        }
    };
    

    if (!orderDetails) return <p>Loading...</p>;

    return (
        <form onSubmit={handleSubmit} style={{display:"flex",flexDirection:"column",marginTop:"100px"}}>
        <Box
        sx={{
            backgroundImage: "url('/productpage/product_image.png')",
            backgroundRepeat: "no-repeat",
            backgroundSize: "100% 100%",
            width: "100%",
            height: "50vh",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    textAlign: "center",
                }}
            >
                <h1 style={{ fontSize: "3rem", fontWeight: "bold", margin: "0", color: "white" }}>Orders</h1>
                <p style={{ fontSize: "1.2rem", marginTop: "10px", color: "white" }}>home / Orders</p>
            </Box>
        <Box sx={{gap:"25px",marginTop:"100px",boxShadow: "0 2px 10px rgba(0,0,0,0.1)",display:"flex",flexDirection:"column",alignItems:"center",width:"50vh",marginRight:"auto",marginLeft:"auto",height:"auto",marginBottom:"100px"}}>
            <h1 style={{marginTop:"25px"}}>Order ID: {orderDetails.order_id}</h1>
            <p>Date Placed: {orderDetails.date_order_placed}</p>
            <p>Status: {orderDetails.order_receieved}</p>
            <p>Product: {orderDetails.product_name}</p>
            <p>Ship to: {orderDetails.user_name}</p>
            <p>Total: {orderDetails.product_cost}</p>
            {orderDetails.order_receieved==='not_yet_received'?(
                <>
            <TextField
            label="otp" 
            onChange={(e)=>{setotp(e.target.value);}}
            sx={{width:"25vh"}}
            />
            <Button sx={{marginBottom:"25px",height:"50px",width:"25vh"}} type="submit"variant="outlined">submit</Button>
            </>
        ):('')}
        </Box>
        <Footer/>
        </form>
    );
    
};

export default OrderDetails;